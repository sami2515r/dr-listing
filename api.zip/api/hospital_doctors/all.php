<?php

require_once "../../includes/cors.php";
require_once "../../includes/response.php";
require_once "../../config/db.php";

$query = "
SELECT
    hd.id,
    hd.doctor_id,
    hd.hospital_id,
    d.name AS doctor_name,
    d.qualification,
    h.name AS hospital_name,
    h.hospital_type,
    ha.city,
    ha.state,
    hd.status,
    hd.created_at
FROM hospital_doctors hd
INNER JOIN doctors d
    ON d.id = hd.doctor_id
INNER JOIN hospitals h
    ON h.id = hd.hospital_id
LEFT JOIN hospital_addresses ha
    ON ha.hospital_id = h.id
WHERE hd.status = 1
ORDER BY hd.id DESC
";

$stmt = $conn->prepare($query);
$stmt->execute();

$links = $stmt->fetchAll(PDO::FETCH_ASSOC);

success("Doctor hospital links fetched successfully", $links);